Hello,

This archive contains several files that document the tool library file formats used for tool onboarding in Fusion.

Several formats can be used to import tools into Fusion. The documents in this archive describe the main ones.
The available import formats are:
•	.tools — a JSON-formatted file packaged in a ZIP archive.
•	.json — a JSON-formatted file; this is the format used by most libraries available on the Autodesk HSM tools website.
•	.hsmlib — the XML-based format used by HSMWorks and Inventor CAM.
•	.csv — a comma-separated values (CSV) file.
Only these formats can be imported directly into Fusion.


Tool manufacturers may provide an Excel file, which can be converted to a JSON file for import.
We provide a conversion script, but Fusion cannot import .xlsx files directly.

Below is an explanation of the content and usage of the files in this archive.
The explanations follow the filenames in alphabetical order, not their importance or usefulness.

First, Excel format information.pdf describes the capabilities and limitations of importing from an Excel file.
Note that this is the least preferred option because it does not support form tools, probes, holders, or turning tools.
In other words, it can only be used for milling tools. It does not support newer tools (for example, circle-segment tools) or form tools.

FusionToolLibrarySchemas.html is an interactive HTML file that lists parameters and variables, along with their types.
It indicates whether a value is a string or a number, provides ranges where applicable, and defines the valid values for each specific tool type.

sample library.json is a JSON-formatted file containing all tools described in the Word document.
It includes milling, turning, probe, and holder definitions (close to forty tools in total).

Sample library-no form tool.csv is the CSV equivalent of the same library, with unsupported types removed (notably form tools).
The CSV uses Fusion’s full layout, which is why it contains many columns (more than 100). By comparison, the Excel import template uses roughly 20 columns because it supports fewer tool types and parameters.

Sample Tooling Schema Including Mills and Hole Making Tools.xlsx is an example of an Excel-formatted library. Please note that it does not contain the exact same tools as the other sample files.

Tool Library Schema Information.docx explains the parameters that describe tool geometry.
For each tool type, it provides an illustration and a description of the relevant parameters.
A JSON snippet is included on each page, showing a single example definition for the tool type being discussed.
